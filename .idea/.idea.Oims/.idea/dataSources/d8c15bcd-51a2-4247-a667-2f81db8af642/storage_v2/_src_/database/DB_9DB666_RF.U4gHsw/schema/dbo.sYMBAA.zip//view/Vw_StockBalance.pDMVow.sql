CREATE VIEW [dbo].[Vw_StockBalance]
AS
SELECT     dbo.Products.ProductName, dbo.Products.Description, dbo.StockItems.Quantity, dbo.POSes.POSName, dbo.StockItems.PosId
FROM         dbo.StockItems INNER JOIN
                      dbo.Products ON dbo.StockItems.ProductId = dbo.Products.ProductId INNER JOIN
                      dbo.POSes ON dbo.StockItems.PosId = dbo.POSes.POSID
go

