create procedure sp_insert_cash_collection
@CollectorName varchar(120),
@TotalCash float,
@TotalCheque float,
@UserId int,
@POSId int
as
insert into CashCollections(CollectorName,CollectionDate,TotalCash,TotalCheque,UserId,POSID)
values(@CollectorName,getdate(),@TotalCash, @TotalCheque, @UserId,   @POSId)
go

