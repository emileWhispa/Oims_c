CREATE PROCEDURE sp_item_delivery
@batchno varchar(20),@salesdetailsid int, @QuantityDelivered int,@QuantityRemaining int,@QuantityPicked int,@userid int
as
declare @productid int, @invoicenumber varchar(20),@SalesId int, @POSId int,@descr varchar(50)
select @productid=ProductId,@SalesId=SalesID from SalesDetails where salesdetailsid=@salesdetailsid
select @invoicenumber=InvoiceNumber,@POSId=POSId from Sales where SalesId=@SalesId
set @descr='Sale Invoice No. '+@invoicenumber
print @productid
print @invoicenumber
print @descr
print @posid
begin tran
insert into dbo.ItemDelivery (BatchNo,SalesDetailsId,QuantityDelivered,QuantityRemaining,QuantityPicked,Status,UserId,DeliveryDate)
values(@BatchNo,@SalesDetailsId,@QuantityDelivered,@QuantityRemaining,@QuantityPicked,0,@UserId,getdate())
exec Sp_UpdateStock @POSId,0,@QuantityPicked,@productid,@descr,@UserId
commit tran
go

