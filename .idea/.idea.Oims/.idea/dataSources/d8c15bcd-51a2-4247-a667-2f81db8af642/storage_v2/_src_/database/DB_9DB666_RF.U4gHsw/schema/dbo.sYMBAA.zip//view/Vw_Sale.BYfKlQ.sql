CREATE VIEW dbo.Vw_Sale
AS
SELECT     CASE Sales.PaymentStatus WHEN 0 THEN 'PROFORMA INVOICE' WHEN 1 THEN 'ORDER' WHEN 2 THEN 'INVOICE' WHEN - 1 THEN 'CANCELLED ORDER' WHEN - 2 THEN
                       'CANCELLED INVOICE' else 'INVOICE' END AS Title, dbo.Customers.CustomerName, dbo.Sales.SalesId, 
                      CASE Sales.PaymentStatus WHEN 0 THEN dbo.Sales.QuoteDate WHEN 1 THEN dbo.Sales.OrderDate WHEN 2 THEN dbo.Sales.InvoiceDate ELSE dbo.Sales.QuoteDate
                       END AS Salesdate, dbo.SalesDetails.UnitPrice * dbo.SalesDetails.Quantity AS Total, dbo.Sales.SalesRef, dbo.SalesDetails.Quantity, dbo.SalesDetails.UnitPrice, 
                      'Cash' AS PaymentName, dbo.Users.FullNames, dbo.SalesDetails.Discounts, dbo.SalesDetails.VAT_Rate, dbo.SalesDetails.Vatable, dbo.SalesDetails.ManualDescr, 
                      dbo.Customers.PhoneNo, dbo.Customers.Address, dbo.Sales.Deposit, dbo.Sales.InvoiceNumber, dbo.Users.Phone, dbo.POSes.POSName, dbo.POSes.POSCode,
                          (SELECT  top (1)   DiscountCode
                            FROM          dbo.Discounts
                            WHERE      (CustomerId = dbo.Sales.DiscountCustomerId)) AS DiscountCode, dbo.Products.ProductName
FROM         dbo.Customers INNER JOIN
                      dbo.Sales ON dbo.Customers.CustomerId = dbo.Sales.CustomerId INNER JOIN
                      dbo.SalesDetails ON dbo.Sales.SalesId = dbo.SalesDetails.SalesId INNER JOIN
                      dbo.Products ON dbo.SalesDetails.ProductId = dbo.Products.ProductId INNER JOIN
                      dbo.Users ON dbo.Sales.MakerId = dbo.Users.UserId INNER JOIN
                      dbo.POSes ON dbo.Sales.POSId = dbo.POSes.POSID
go

exec sp_addextendedproperty 'MS_DiagramPane1', N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[61] 4[4] 2[15] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "Customers"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 125
               Right = 200
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "Sales"
            Begin Extent = 
               Top = 0
               Left = 374
               Bottom = 280
               Right = 536
            End
            DisplayFlags = 280
            TopColumn = 1
         End
         Begin Table = "SalesDetails"
            Begin Extent = 
               Top = 126
               Left = 38
               Bottom = 324
               Right = 198
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "Products"
            Begin Extent = 
               Top = 169
               Left = 598
               Bottom = 288
               Right = 779
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "Users"
            Begin Extent = 
               Top = 20
               Left = 797
               Bottom = 218
               Right = 977
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "POSes"
            Begin Extent = 
               Top = 6
               Left = 574
               Bottom = 159
               Right = 734
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 22
         Width = 284
         Width = 1500
         Width = 1500
      ', 'SCHEMA', 'dbo', 'VIEW', 'Vw_Sale'
go

exec sp_addextendedproperty 'MS_DiagramPane2', N'   Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', 'SCHEMA', 'dbo', 'VIEW', 'Vw_Sale'
go

exec sp_addextendedproperty 'MS_DiagramPaneCount', 2, 'SCHEMA', 'dbo', 'VIEW', 'Vw_Sale'
go

