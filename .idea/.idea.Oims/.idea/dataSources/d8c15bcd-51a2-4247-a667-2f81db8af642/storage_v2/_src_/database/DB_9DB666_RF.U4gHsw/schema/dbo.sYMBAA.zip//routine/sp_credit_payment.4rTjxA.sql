CREATE procedure sp_credit_payment
@CreditId int,@OpeningBalance float, @salesId int, @PaymentModeId int, @Amount float, @userId int, @DocNo varchar(30), @CustomerId int
as
begin tran
insert into SalesPayments(SalesId,PaymentDate,PaymentModeId,Amount,UserId,DocumentNo,PaymentType)
values (@salesId,getdate(),@PaymentModeId,@Amount,@userId,@DocNo,'Credit')
--Insert details into Credit Payment
insert into CreditPayments (CreditId,Amount,PaymentDate,OpeningBalance,PaymentModeId)
values (@CreditId,@Amount,getdate(),@OpeningBalance,@PaymentModeId)

--Update CreditSales Table
update CreditSales set PaidAmount=isnull(PaidAmount,0)+@Amount where CreditId=@CreditId
declare @CreditAmount float, @PaidAmount float
select @CreditAmount=Amount, @PaidAmount=PaidAmount from CreditSales where CreditId=@CreditId
if @CreditAmount=@PaidAmount
begin
	update CreditSales set PaymentStatus=2 where CreditId=@CreditId--Fully Settled
       update sales set PaymentStatus=4 where salesID=@salesId
end
else
	update CreditSales set PaymentStatus=1 where CreditId=@CreditId--Partial Settled
--Updating customer balance
update Customers set Balance = isnull(balance,0)-@Amount where CustomerId=@CustomerId
commit tran
go

