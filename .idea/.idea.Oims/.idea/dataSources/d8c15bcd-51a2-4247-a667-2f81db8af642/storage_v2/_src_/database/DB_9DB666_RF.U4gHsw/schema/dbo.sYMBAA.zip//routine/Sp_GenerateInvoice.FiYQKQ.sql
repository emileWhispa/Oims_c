
CREATE PROCEDURE [dbo].[Sp_GenerateInvoice] 
@UserId int
AS
Declare @InvoiceNo int,@Result Varchar(20),@POSCode varchar(5),@year int

	BEGIN
		SET NOCOUNT ON;
		select @POSCode=POSCode from POSes where POSId=(Select POSId from Users where UserId=@UserId)
		select @year=datepart(year,getdate())
		--Select @InvoiceNo = InvoiceNumber From InvoiceNumbers where POSCode=@POSCode and Year=@Year
	if not exists(Select InvoiceNumber From InvoiceNumbers where POSCode=@POSCode and Year=@Year)
	begin
		insert into InvoiceNumbers(POSCode,[Year],InvoiceNumber) values (@POSCode,@Year,1)
		set @InvoiceNo=0
	end
	else
	begin
		Select @InvoiceNo = InvoiceNumber From InvoiceNumbers where POSCode=@POSCode and Year=@Year
		UPDATE InvoiceNumbers set InvoiceNumber=InvoiceNumber+1 where POSCode=@POSCode and Year=@Year
	end
	set @InvoiceNo=@InvoiceNo+1--Increment by 1
	set @Result= @POSCode+'/' +(Select Replicate('0', 6-len(convert(varchar(20),@InvoiceNo))) + '' + convert(varchar(20),@InvoiceNo))+ '/'+convert(varchar(20),@Year)
	Select  @Result
	END


go

