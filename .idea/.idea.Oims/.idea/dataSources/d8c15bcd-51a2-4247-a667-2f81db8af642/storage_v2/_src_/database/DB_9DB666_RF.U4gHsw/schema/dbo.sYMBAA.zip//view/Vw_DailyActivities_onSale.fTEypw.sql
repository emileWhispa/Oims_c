CREATE VIEW [dbo].[Vw_DailyActivities_onSale]
AS
SELECT     TOP (100) PERCENT dbo.Sales.SalesRef,ISNULL(dbo.Sales.InvoiceDate, dbo.Sales.QuoteDate) AS Date, SUM(dbo.SalesDetails.Quantity * dbo.SalesDetails.UnitPrice) 
                      - SUM(dbo.SalesDetails.Quantity * dbo.SalesDetails.UnitPrice * dbo.SalesDetails.Discounts / 100) 
                      + SUM((dbo.SalesDetails.Quantity * dbo.SalesDetails.UnitPrice - dbo.SalesDetails.Quantity * dbo.SalesDetails.UnitPrice * dbo.SalesDetails.Discounts / 100) 
                      * (dbo.SalesDetails.VAT_Rate / 100)) AS TotalAmount, 
                      SUM((dbo.SalesDetails.Quantity * dbo.SalesDetails.UnitPrice - dbo.SalesDetails.Quantity * dbo.SalesDetails.UnitPrice * dbo.SalesDetails.Discounts / 100) 
                      * (dbo.SalesDetails.VAT_Rate / 100)) AS VAT, 
                      SUM(dbo.SalesDetails.Quantity * dbo.SalesDetails.UnitPrice - dbo.SalesDetails.Quantity * dbo.SalesDetails.UnitPrice * dbo.SalesDetails.Discounts / 100) AS NET, 
                      CASE (dbo.Sales.PaymentStatus) 
                      WHEN - 1 THEN 'Cancelled' WHEN '2' THEN 'Invoice' WHEN '3' THEN 'Partially Paid' WHEN '4' THEN 'Fully Paid' WHEN '5' THEN 'Partially Delivered' WHEN '6' THEN
                       'Fully Delivered' ELSE 'Invoice' END AS Status, dbo.POSes.POSID, dbo.POSes.POSName, dbo.Customers.CustomerName, dbo.Customers.CustomerId, 
                      dbo.Users.UserId, dbo.Users.FullNames, dbo.Sales.InvoiceNumber, dbo.Sales.SDCReceiptNo, dbo.Sales.SDCNo
FROM         dbo.Sales INNER JOIN
                      dbo.SalesDetails ON dbo.Sales.SalesId = dbo.SalesDetails.SalesId INNER JOIN
                      dbo.POSes ON dbo.Sales.POSId = dbo.POSes.POSID INNER JOIN
                      dbo.Customers ON dbo.Sales.CustomerId = dbo.Customers.CustomerId INNER JOIN
                      dbo.Users ON dbo.Sales.ApproverId = dbo.Users.UserId AND dbo.Sales.MakerId = dbo.Users.UserId
WHERE     (dbo.Sales.PaymentStatus NOT IN (0, 1))
GROUP BY dbo.Sales.SalesRef, dbo.Sales.QuoteDate, dbo.Sales.PaymentStatus, dbo.POSes.POSID, dbo.POSes.POSName, dbo.Customers.CustomerName, 
                      dbo.Customers.CustomerId, dbo.Users.UserId, dbo.Users.FullNames, dbo.Sales.InvoiceNumber, dbo.Sales.SDCReceiptNo, dbo.Sales.SDCNo, dbo.Sales.InvoiceDate

ORDER BY Date DESC
go

