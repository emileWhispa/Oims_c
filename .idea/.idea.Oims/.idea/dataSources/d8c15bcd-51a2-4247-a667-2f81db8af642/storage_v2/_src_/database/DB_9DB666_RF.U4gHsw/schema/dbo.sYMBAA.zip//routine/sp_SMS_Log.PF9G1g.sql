create procedure sp_SMS_Log
(
	@CustomerName [varchar](50) ,
	@InvoiceNo [varchar](50),
	@Status [varchar](5),
	@Balance [int] 
)
AS
insert into SMSLog (CustomerName, InvoiceNo, Status, Balance)
values (@CustomerName, @InvoiceNo, @Status, @Balance)
go

