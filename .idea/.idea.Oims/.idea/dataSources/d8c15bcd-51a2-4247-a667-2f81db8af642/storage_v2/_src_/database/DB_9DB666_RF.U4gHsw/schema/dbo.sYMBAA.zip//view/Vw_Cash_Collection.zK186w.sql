CREATE VIEW [dbo].[Vw_Cash_Collection]
AS
SELECT     dbo.CashCollections.CashCollectionId, dbo.CashCollections.CollectorName, dbo.CashCollections.CollectionDate, dbo.CashCollections.TotalCash, 
                      dbo.CashCollections.TotalCheque, dbo.CashCollections.TotalCash + dbo.CashCollections.TotalCheque AS TotalAmount, dbo.Users.FullNames, 
                      dbo.POSes.POSName
FROM         dbo.CashCollections INNER JOIN
                      dbo.Users ON dbo.CashCollections.UserId = dbo.Users.UserId INNER JOIN
                      dbo.POSes ON dbo.Users.POSID = dbo.POSes.POSID

go

