CREATE VIEW [dbo].[Vw_POS_Orders]
AS
SELECT     dbo.POSOrders.OrderId, dbo.POSOrders.OrderDate, dbo.POSOrders.DeliveryDate, dbo.POSes.POSName, dbo.Products.ProductName, 
                      dbo.OrderItems.QuantityOrdered, dbo.OrderItems.QuantityDelivered, dbo.OrderItems.QuantityReceived, dbo.POSOrders.ReceptionDate, dbo.POSOrders.DispatchDate, 
                      dbo.POSOrders.OrderStatus, dbo.POSOrders.Status, dbo.Users.UserName
FROM         dbo.POSOrders INNER JOIN
                      dbo.OrderItems ON dbo.POSOrders.OrderId = dbo.OrderItems.OrderId INNER JOIN
                      dbo.POSes ON dbo.POSOrders.POSId = dbo.POSes.POSID INNER JOIN
                      dbo.Products ON dbo.OrderItems.ProductId = dbo.Products.ProductId INNER JOIN
                      dbo.Users ON dbo.POSOrders.UserId = dbo.Users.UserId
go

