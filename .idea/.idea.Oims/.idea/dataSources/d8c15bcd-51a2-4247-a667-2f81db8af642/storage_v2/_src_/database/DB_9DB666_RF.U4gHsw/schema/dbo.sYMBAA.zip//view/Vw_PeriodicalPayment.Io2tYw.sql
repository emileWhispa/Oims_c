CREATE VIEW [dbo].[Vw_PeriodicalPayment]
AS
SELECT     dbo.SalesPayments.PaymentDate, dbo.PaymentModes.PaymentName, dbo.SalesPayments.PaymentType, dbo.SalesPayments.Amount, 
                      CASE (dbo.SalesPayments.PaymentType) WHEN 'Invoice' THEN InvoiceNumber WHEN 'Credit' THEN InvoiceNumber ELSE SalesRef END AS [Document No], 
                      dbo.Customers.CustomerName, dbo.POSes.POSName, dbo.Customers.CustomerId, dbo.POSes.POSID, dbo.PaymentModes.ModeId
FROM         dbo.SalesPayments INNER JOIN
                      dbo.Sales ON dbo.SalesPayments.SalesId = dbo.Sales.SalesId INNER JOIN
                      dbo.Customers ON dbo.Sales.CustomerId = dbo.Customers.CustomerId INNER JOIN
                      dbo.PaymentModes ON dbo.SalesPayments.PaymentModeId = dbo.PaymentModes.ModeId INNER JOIN
                      dbo.POSes ON dbo.Sales.POSId = dbo.POSes.POSID


go

