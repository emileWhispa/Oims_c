CREATE procedure sp_reverse_cash_collection
@CashCollectionId int,@UserId int
as
declare @TotalCash float,@TotalCheque float,@openBalCash float, @openBalCheque float
--inserting details into TellerBalances
select @openBalCash=TotalCash, @openBalCheque=TotalCheque from TellerBalances where UserId=@UserId

select @TotalCash=TotalCash,@TotalCheque=TotalCheque
from CashCollections
where CashCollectionId=@CashCollectionId
		update TellerBalances set TotalCash=TotalCash+@totalCash, TotalCheque=TotalCheque+@TotalCheque where UserId=@userId
	insert into dbo.TellerTransactionDetails(SalesPaymentId,UserId,CashOpeningBal,CashAmount,ChequeOpeningBal,ChequeAmount,Description,TransactionDate)
		values(@CashCollectionId,@userID,isnull(@openBalCash,0),@totalCash,isnull(@openBalCheque,0),@TotalCheque,'Cash Collection Reversal',getdate())
update CashCollections set Cancelled=1 where CashCollectionId=@CashCollectionId
go

