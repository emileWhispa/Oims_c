CREATE TRIGGER [dbo].[Exp_update_teller_balance] 
   ON Expenses
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

declare @ExpenseId int,@Description varchar(130), @Amount decimal (18,2),
@userId int,@openBalCash float, @openBalCheque float
select @ExpenseId=ExpenseId,@Description=Description,
@Amount=Amount,@userId=userId  from inserted
--inserting details into TellerBalances
select @openBalCash=TotalCash, @openBalCheque=TotalCheque from TellerBalances where UserId=@UserId
	if not exists (select * from TellerBalances where UserID=@UserId)
	begin
				rollback tran
				raiserror('This user has no cash in the system!',16,1)
	end
	else
	begin
		update TellerBalances set TotalCash=TotalCash-@Amount where UserId=@userId
	insert into dbo.TellerTransactionDetails(SalesPaymentId,UserId,CashOpeningBal,CashAmount,ChequeOpeningBal,ChequeAmount,Description,TransactionDate)
		values(@ExpenseId,@userID,isnull(@openBalCash,0),@Amount*-1,isnull(@openBalCheque,0),0,@Description,getdate())
	end

END
go

