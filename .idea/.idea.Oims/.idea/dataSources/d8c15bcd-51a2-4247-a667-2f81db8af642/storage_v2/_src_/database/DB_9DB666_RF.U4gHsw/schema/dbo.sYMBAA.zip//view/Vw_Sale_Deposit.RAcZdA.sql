CREATE VIEW [dbo].[Vw_Sale_Deposit]
AS
SELECT     dbo.Sales.SalesId, dbo.Sales.QuoteDate, dbo.Sales.Deposit, dbo.Sales.SalesRef, dbo.Customers.CustomerName, dbo.Users.FullNames, dbo.POSes.POSName, 
                      dbo.Users.UserId, dbo.POSes.POSID
FROM         dbo.Customers INNER JOIN
                      dbo.Sales ON dbo.Customers.CustomerId = dbo.Sales.CustomerId INNER JOIN
                      dbo.POSes ON dbo.Sales.POSId = dbo.POSes.POSID INNER JOIN
                      dbo.Users ON dbo.Sales.MakerId = dbo.Users.UserId
WHERE     (dbo.Sales.Deposit > 0)
go

