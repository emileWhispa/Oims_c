CREATE VIEW [dbo].[Vw_Expenses]
AS
SELECT     dbo.ExpenseCategories.SageLedgerNo, dbo.Expenses.ExpenseDate, dbo.Expenses.Description, dbo.Expenses.Amount, dbo.Currencies.CurrencyCode, 
                      dbo.Expenses.ExchangeRate, dbo.Users.FullNames AS PostedBy, dbo.ExpenseCategories.ExpenseName, dbo.Expenses.UserId
FROM         dbo.Expenses INNER JOIN
                      dbo.Users ON dbo.Expenses.UserId = dbo.Users.UserId INNER JOIN
                      dbo.Currencies ON dbo.Expenses.CurrencyId = dbo.Currencies.CurrencyId INNER JOIN
                      dbo.ExpenseCategories ON dbo.Expenses.ExpenseCategoryId = dbo.ExpenseCategories.ExpenseCategoryId
go

