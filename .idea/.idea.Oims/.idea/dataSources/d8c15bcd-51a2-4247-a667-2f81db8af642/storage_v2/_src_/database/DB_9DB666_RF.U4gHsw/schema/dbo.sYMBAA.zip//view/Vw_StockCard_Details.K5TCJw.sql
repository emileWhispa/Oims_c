CREATE VIEW [dbo].[Vw_StockCard_Details]
AS
SELECT     TOP (100) PERCENT dbo.Products.ProductName, dbo.StockCard.OpeningQuantity, dbo.StockCard.QuantityIn, dbo.StockCard.QuantityOut, dbo.StockCard.Description, 
                      dbo.Users.FullNames, dbo.POSes.POSName, dbo.Products.Description AS ItemFullName, dbo.StockCard.TranDate, dbo.StockCard.ProductId, dbo.StockCard.PosId, 
                      dbo.StockCard.StockCardId
FROM         dbo.StockCard INNER JOIN
                      dbo.Users ON dbo.StockCard.UserId = dbo.Users.UserId INNER JOIN
                      dbo.Products ON dbo.StockCard.ProductId = dbo.Products.ProductId INNER JOIN
                      dbo.POSes ON dbo.StockCard.PosId = dbo.POSes.POSID
ORDER BY dbo.StockCard.StockCardId
go

