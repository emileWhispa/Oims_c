

CREATE procedure [dbo].[sp_initialize_all]
as
truncate table dbo.StockCard
truncate table dbo.StockItems
truncate table dbo.SpecialOrders
truncate table dbo.SalesPayments
truncate table dbo.SalesDetails
delete from dbo.Sales
DBCC CHECKIDENT ('Sales',reseed,0)
truncate table dbo.ProductionItems
delete from dbo.Productions
DBCC CHECKIDENT ('Productions',reseed,0)
truncate table dbo.ReceiptNumbers
insert into dbo.ReceiptNumbers(ReceiptNum,InvoiceNumber) values (0,0)
truncate table dbo.OrderItems
truncate table dbo.OrderDispatch
delete from dbo.POSOrders
DBCC CHECKIDENT ('POSOrders',reseed,0)
truncate table dbo.POSItemTransfers
truncate table dbo.Pass_Hist
truncate table dbo.ItemDelivery
truncate table dbo.InvoiceNumbers
truncate table dbo.Expenses
truncate table dbo.Discounts
--delete from dbo.Customers
--DBCC CHECKIDENT ('Customers',reseed,0)
truncate table dbo.CreditPayments
truncate table dbo.CashCollections
truncate table dbo.BankTransactions
--delete from products
--DBCC CHECKIDENT ('products',reseed,0)


go

