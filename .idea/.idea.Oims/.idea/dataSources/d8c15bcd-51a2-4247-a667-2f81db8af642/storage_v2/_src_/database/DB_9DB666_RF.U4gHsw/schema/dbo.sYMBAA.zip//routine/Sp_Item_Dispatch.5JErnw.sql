


CREATE PROCEDURE [dbo].[Sp_Item_Dispatch] 
@OrderId int, @UserId int
	AS 
if exists (select * from POSOrders where Orderstatus=2 and OrderId=@OrderId)
begin
	raiserror ('Order Already Dispatched',16,1)
end
ELSE
BEGIN
		SET NOCOUNT ON;
		declare @prd int;
		declare @Units int;
		DECLARE @prdcode int;
		DECLARE @PosId int;
		DECLARE @Descr varchar(50);
		DECLARE @AvailableQty int;
DECLARE Pro_CURSOR CURSOR FOR SELECT DISTINCT productId,QuantityDelivered  FROM OrderItems where OrderId=@OrderId;
OPEN Pro_CURSOR;
BEGIN TRAN
set @PosId=(select posid from POSes where Mainstore=1);
FETCH NEXT FROM Pro_CURSOR INTO @prd, @units;
	WHILE @@FETCH_STATUS =0  
	BEGIN
			select @prdcode=productid, @AvailableQty=Quantity from stockitems where Posid=@PosId and ProductId=@prd
			set @Descr='Dispatch for Order No. '+convert(varchar(10),@OrderId)
			if @prdcode is null or @prdcode=''
				 begin
					ROLLBACK TRAN
					raiserror('Stock Unavailable for this product',16,1)
					break
				 end
			else
				begin
					IF @AvailableQty<@units
					BEGIN
						ROLLBACK TRAN
						raiserror('Insufficient Quantity for this product',16,1)
						break
					END
					ELSE
					BEGIN
					--insert into stock card table
	       				insert into StockCard (ProductId,POsId,OpeningQuantity,QuantityIn, QuantityOut,Description,UserId, TranDate) values
					(@prd,@Posid,isnull(@availableQty,0),0,@Units,@Descr,@userid,getdate())
					Update StockItems set quantity=Quantity-@Units where Posid=@PosId and ProductId=@prd
					END
				end
		FETCH NEXT FROM Pro_CURSOR INTO @prd, @units;
	End
CLOSE Pro_CURSOR;
DEALLOCATE Pro_CURSOR;
update POSOrders set Orderstatus=2, DispatcherId=@UserId, DeliveryDate=getdate() where OrderId=@OrderId
COMMIT TRAN
END
go

