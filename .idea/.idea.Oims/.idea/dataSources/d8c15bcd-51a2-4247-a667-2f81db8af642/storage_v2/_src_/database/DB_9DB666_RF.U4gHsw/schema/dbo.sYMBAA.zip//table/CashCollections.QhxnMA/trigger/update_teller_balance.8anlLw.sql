CREATE TRIGGER update_teller_balance 
   ON  dbo.CashCollections
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

declare @CashCollectionId int,@CollectionDate datetime, @CollectorName varchar(120), @totalCash decimal (18,2),
@userId int,@openBalCash float, @openBalCheque float, @TotalCheque float
select @CashCollectionId=CashCollectionId,@CollectionDate=CollectionDate,@CollectorName=CollectorName,
@totalCash=totalCash,@userId=userId,@TotalCheque=TotalCheque from inserted
--inserting details into TellerBalances
select @openBalCash=TotalCash, @openBalCheque=TotalCheque from TellerBalances where UserId=@UserId
	if not exists (select * from TellerBalances where UserID=@UserId)
	begin
				rollback tran
				raiserror('This user hasn''t done any cash or cheque sale previously!',16,1)
	end
	else
	begin
		update TellerBalances set TotalCash=TotalCash-@totalCash, TotalCheque=TotalCheque-@TotalCheque where UserId=@userId
	insert into dbo.TellerTransactionDetails(SalesPaymentId,UserId,CashOpeningBal,CashAmount,ChequeOpeningBal,ChequeAmount,Description,TransactionDate)
		values(@CashCollectionId,@userID,isnull(@openBalCash,0),@totalCash*-1,isnull(@openBalCheque,0),@TotalCheque*-1,'Cash Collection',getdate())
	end

END
go

