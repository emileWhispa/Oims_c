





CREATE PROCEDURE [dbo].[Sp_GenerateReceipt] 
AS
Declare @Receipt Varchar(20),@Result Varchar(20)
	BEGIN
		SET NOCOUNT ON;
		Select @Receipt = ReceiptNum From ReceiptNumbers
		--- Reset the seq no if greater than 999999900
		If @Receipt >= 999999900 or @Receipt is null
			Begin
				--Truncate Table ReceiptNumbers
				Update ReceiptNumbers set ReceiptNum='000001'
				Select @Receipt = ReceiptNum From ReceiptNumbers
			End
			--Delete From ReceiptNumbers;
		Update ReceiptNumbers set ReceiptNum=@Receipt +1
		set @Result='SO/' +(Select Replicate('0', 5-len(ReceiptNum)) + '' + ReceiptNum as ReceiptNo  From ReceiptNumbers)
	  Select  @Result
	END


go

