




/*-- =============================================
-- Author      : Jean Claude NKIZABAGABO
-- Create date : Sep 20 2015  1:00PM
-- Description : Insert Procedure for Sales
-- Exec [dbo].[usp_InsertSales] [QuoteDate],[Remarks],[CustomerId],[DeliveryDate],[Deposit],[OrderDate],[InvoiceDate],[SalesRef],[MakerId],[ApproverId],[PaymentStatus],[InvoiceNumber]
-- ============================================= */
CREATE PROCEDURE [dbo].[usp_InsertSales]
     @QuoteDate  datetime
    ,@Remarks  varchar(200)
    ,@CustomerId  int
    ,@Deposit  decimal
    ,@SalesRef  varchar(14)
    ,@MakerId  int
	,@DiscountCustomerId int 
AS
BEGIN
declare 	@POSId int   
select @POSId=POSId from Users where UserID=@MakerId
    INSERT INTO [dbo].[Sales]
    ( 
         [QuoteDate]
        ,[Remarks]
        ,[CustomerId]
        ,[Deposit]
        ,[SalesRef]
        ,[MakerId]
        ,[PaymentStatus]
        ,[POSId]
		,[DiscountCustomerId]
    )
    VALUES
    (
         @QuoteDate
        ,@Remarks
        ,@CustomerId
        ,@Deposit
        ,@SalesRef
        ,@MakerId 
		,0--Pending
		,@POSId    
		,@DiscountCustomerId   
    )
return @@identity --to return the salesId
END


go

