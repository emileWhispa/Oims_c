CREATE VIEW [dbo].[Vw_Special_Orders]
AS
SELECT     a.SpecialOrderId, a.Descr, a.Quantity, a.OrderDate, a.ExpectedDeliveryDate, a.Amount, a.Sample, c.CustomerName, d.CategoryName, b.POSName AS OriginPOS,
                          (SELECT     POSName
                            FROM          dbo.POSes
                            WHERE      (POSID = a.CollectionPos)) AS CollectionPOSName, 
                      CASE a.OrderStatus WHEN 0 THEN 'Pending' WHEN 1 THEN 'Submitted' WHEN 2 THEN 'Processing' WHEN 3 THEN 'Dispatched' WHEN 4 THEN 'Received' WHEN 5 THEN
                       'Collected' ELSE 'Unknown' END AS Status
FROM         dbo.SpecialOrders AS a INNER JOIN
                      dbo.POSes AS b ON a.POSId = b.POSID INNER JOIN
                      dbo.ProductCategories AS d ON a.ProductCategoryId = d.ProductCategoryId INNER JOIN
                      dbo.Customers AS c ON a.CustomerId = c.CustomerId
go

