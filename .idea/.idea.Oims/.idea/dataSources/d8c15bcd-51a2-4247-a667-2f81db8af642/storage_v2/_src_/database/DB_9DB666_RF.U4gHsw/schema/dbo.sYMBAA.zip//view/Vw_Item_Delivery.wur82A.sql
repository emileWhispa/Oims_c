CREATE VIEW [dbo].[Vw_Item_Delivery]
AS
SELECT     dbo.SalesDetails.Quantity, dbo.Products.ProductName, dbo.SalesDetails.SalesDetailsId, ISNULL
                          ((SELECT     SUM(QuantityPicked) AS Expr1
                              FROM         dbo.ItemDelivery
                              WHERE     (SalesDetailsId = dbo.SalesDetails.SalesDetailsId)), 0) AS QuantityDelivered, dbo.SalesDetails.SalesId, dbo.Sales.InvoiceNumber, 
                      dbo.Products.ProductId, dbo.Sales.POSId, dbo.Sales.PaymentStatus
FROM         dbo.SalesDetails INNER JOIN
                      dbo.Products ON dbo.SalesDetails.ProductId = dbo.Products.ProductId INNER JOIN
                      dbo.Sales ON dbo.SalesDetails.SalesId = dbo.Sales.SalesId
go

