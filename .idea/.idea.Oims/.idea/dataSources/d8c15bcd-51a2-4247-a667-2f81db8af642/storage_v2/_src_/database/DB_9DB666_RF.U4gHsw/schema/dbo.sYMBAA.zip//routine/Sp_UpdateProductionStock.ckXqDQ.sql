



CREATE PROCEDURE [dbo].[Sp_UpdateProductionStock] 
@BatchId int, @UserId int
	AS 
	BEGIN
		SET NOCOUNT ON;
		declare @prd int;
		declare @Units int;
		DECLARE @prdcode int;
		DECLARE @PosId int;
		DECLARE @Descr varchar(50);
		DECLARE @AvailableQty int;
DECLARE Pro_CURSOR CURSOR FOR SELECT DISTINCT productId,units  FROM ProductionItems where ProductionId=@batchid;
OPEN Pro_CURSOR;
set @PosId=(select posid from POSes where Mainstore=1);
FETCH NEXT FROM Pro_CURSOR INTO @prd, @units;
	WHILE @@FETCH_STATUS =0  
	BEGIN
			select @prdcode=productid, @AvailableQty=Quantity from stockitems where Posid=@PosId and ProductId=@prd
			set @Descr='Production No. '+convert(varchar(10),@batchid)
			if @prdcode is null or @prdcode=''
				 begin
					--insert into stock card table
					insert into StockCard (ProductId,POsId,OpeningQuantity,QuantityIn, QuantityOut,Description,UserId, TranDate) values
					(@prd,@Posid,isnull(@availableQty,0),@Units,0,@Descr,@userid,getdate())
					INSERT INTO StockItems(ProductId,PosId,Quantity) VALUES(@prd,@PosId,@Units);
				 end
			else
				begin
					--insert into stock card table
					insert into StockCard (ProductId,POsId,OpeningQuantity,QuantityIn, QuantityOut,Description,UserId, TranDate) values
					(@prd,@Posid,isnull(@availableQty,0),@Units,0,@Descr,@userid,getdate())
					Update StockItems set quantity=Quantity+@Units where Posid=@PosId and ProductId=@prd
				end
		FETCH NEXT FROM Pro_CURSOR INTO @prd, @units;
	End
CLOSE Pro_CURSOR;
DEALLOCATE Pro_CURSOR;
end


go

