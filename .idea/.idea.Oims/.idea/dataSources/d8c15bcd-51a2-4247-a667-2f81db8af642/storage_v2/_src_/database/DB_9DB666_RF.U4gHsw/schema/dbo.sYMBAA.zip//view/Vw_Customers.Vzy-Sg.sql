CREATE VIEW [dbo].[Vw_Customers]
AS
SELECT     TOP (100) PERCENT CustomerName, PhoneNo, Address, Distributor, Balance
FROM         dbo.Customers
ORDER BY CustomerName
go

