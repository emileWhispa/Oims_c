





CREATE PROCEDURE [dbo].[Sp_UpdateStock] 
@Posid int,@action int,@Qty int,@prd int, @description varchar(50),@userid int
AS 
	BEGIN
		SET NOCOUNT ON;
		Declare @prdcode int, @availableQty int,@res int
		select @prdcode=productid,@availableQty=Quantity from stockitems where Posid=@PosId and ProductId=@prd
	If @action =0 --- reduce
		Begin
			if(isnull(@availableQty,0)-@qty)<0
			begin
				set @res=-1
				raiserror('Stock Unavailable/Insufficient for this product',16,1)
			end

			else
				begin
					--insert into stock card table
					insert into StockCard (ProductId,POsId,OpeningQuantity,QuantityIn, QuantityOut,Description,UserId, TranDate) values
					(@prd,@Posid,isnull(@availableQty,0),0,@qty,@description,@userid,getdate())
					Update StockItems set quantity=Quantity-@Qty where Posid=@Posid and ProductId=@prd
					set @res=1
				end
		End
	else  --increase stock
		if @prdcode is null or @prdcode=''
			begin
					--insert into stock card table
					insert into StockCard (ProductId,POsId,OpeningQuantity,QuantityIn, QuantityOut,Description,UserId, TranDate) values
					(@prd,@Posid,isnull(@availableQty,0),@qty,0,@description,@userid,getdate())
				INSERT INTO StockItems(ProductId,PosId,Quantity) VALUES(@prd,@PosId,@Qty);
					set @res=1
			end
			else
				begin
					--insert into stock card table
					insert into StockCard (ProductId,POsId,OpeningQuantity,QuantityIn, QuantityOut,Description,UserId, TranDate) values
					(@prd,@Posid,isnull(@availableQty,0),@qty,0,@description,@userid,getdate())
					Update StockItems set quantity=Quantity+@Qty where Posid=@Posid and ProductId=@prd
					set @res=1
				end
select @res
 End


go

