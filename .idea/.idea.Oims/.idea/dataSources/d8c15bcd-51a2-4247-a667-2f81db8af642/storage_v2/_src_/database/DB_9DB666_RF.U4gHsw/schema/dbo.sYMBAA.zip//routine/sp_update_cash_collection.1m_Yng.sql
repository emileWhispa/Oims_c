create procedure sp_update_cash_collection
@CashCollectionId int,
@CollectorName varchar(120),
@TotalCash float,
@TotalCheque float,
@UserId int,
@POSId int
as
update CashCollections set CollectorName=@CollectorName,TotalCash=@TotalCash,TotalCheque=@TotalCheque,UserId=@UserId,POSID=@POSId
where CashCollectionId=@CashCollectionId
go

