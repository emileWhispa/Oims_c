CREATE VIEW [dbo].[Vw_Teller_Details]
AS
SELECT     TOP (100) PERCENT dbo.TellerTransactionDetails.TransactionDate, dbo.TellerTransactionDetails.CashOpeningBal, dbo.TellerTransactionDetails.CashAmount, 
                      dbo.TellerTransactionDetails.CashOpeningBal + dbo.TellerTransactionDetails.CashAmount AS CashBal, dbo.TellerTransactionDetails.ChequeOpeningBal, 
                      dbo.TellerTransactionDetails.ChequeAmount, dbo.TellerTransactionDetails.ChequeOpeningBal + dbo.TellerTransactionDetails.ChequeAmount AS ChequeBal, 
                      dbo.Users.FullNames, dbo.TellerTransactionDetails.UserId, dbo.TellerTransactionDetails.TransactionDetailsId, CASE WHEN (CashAmount >= 0) 
                      THEN CASE WHEN (PaymentStatus = 1) THEN SalesRef ELSE InvoiceNumber END ELSE dbo.TellerTransactionDetails.Description END AS Description, 
                      dbo.TellerTransactionDetails.Description AS TellerDescription
FROM         dbo.TellerTransactionDetails INNER JOIN
                      dbo.Users ON dbo.TellerTransactionDetails.UserId = dbo.Users.UserId INNER JOIN
                      dbo.SalesPayments ON dbo.TellerTransactionDetails.SalesPaymentId = dbo.SalesPayments.SalesPaymentId INNER JOIN
                      dbo.Sales ON dbo.SalesPayments.SalesId = dbo.Sales.SalesId
ORDER BY dbo.TellerTransactionDetails.TransactionDetailsId
go

