


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[credit_sale]
   ON  [dbo].[SalesPayments]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

declare @SalesPaymentId int,@PaymentDate datetime, @PaymentModeId int, @amt decimal (18,2),@userId int, 
@tranId int,@openBalCash float, @openBalCheque float, @SalesId int
select @SalesPaymentId=SalesPaymentId, @SalesId=SalesId,@PaymentDate=PaymentDate,@amt=amount,@userId=userId,@PaymentModeId=PaymentModeId from inserted
if(@PaymentModeId=4)--credit sale
begin
	declare @cust_bal float, @customerId int
	select @customerId = CustomerId from Sales where SalesId=@SalesId
	select @cust_bal=balance from Customers where CustomerId=@customerId
	insert into CreditSales(SalesPaymentId,OpeningBalance,CreditDate,Amount,UserId) 
	values (@SalesPaymentId,isnull(@cust_bal,0),@PaymentDate,@amt,@userId)
	update Customers set balance=isnull(balance,0)+@amt where CustomerId=@customerId
end
--inserting details into TellerBalances
select @openBalCash=TotalCash, @openBalCheque=TotalCheque from TellerBalances where UserId=@UserId
if(@PaymentModeId=1)--cash sale
begin
	if not exists (select * from TellerBalances where UserID=@UserId)
	begin
		insert into dbo.TellerBalances (UserId,TotalCash,TotalCheque)values(@UserId,@amt,0)
	end
	else
	begin
		update TellerBalances set TotalCash=TotalCash+@amt where UserId=@userId
	end
	insert into dbo.TellerTransactionDetails(SalesPaymentId,UserId,CashOpeningBal,CashAmount,ChequeOpeningBal,ChequeAmount,Description,TransactionDate)
		values(@SalesPaymentId,@userID,isnull(@openBalCash,0),@amt,isnull(@openBalCheque,0),0,'Cash Sale',getdate())
end
else if(@PaymentModeId=2)--cheque sale
begin
	if not exists (select * from TellerBalances where UserID=@UserId)
	begin
		insert into dbo.TellerBalances (UserId,TotalCash,TotalCheque)values(@UserId,0,@amt)
	end
	else
	begin
		update TellerBalances set TotalCheque=TotalCheque+@amt where UserId=@userId
	end
		insert into dbo.TellerTransactionDetails(SalesPaymentId,UserId,CashOpeningBal,CashAmount,ChequeOpeningBal,ChequeAmount,Description,TransactionDate)
		values(@SalesPaymentId,@userID,isnull(@openBalCash,0),0,isnull(@openBalCheque,0),@amt,'Cheque Sale',getdate())
end

END


go

