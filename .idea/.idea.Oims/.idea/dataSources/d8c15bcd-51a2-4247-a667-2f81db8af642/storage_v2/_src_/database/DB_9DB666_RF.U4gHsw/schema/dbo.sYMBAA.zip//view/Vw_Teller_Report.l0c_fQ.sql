CREATE VIEW [dbo].[Vw_Teller_Report]
AS
SELECT     TOP (100) PERCENT dbo.TellerTransactionDetails.TransactionDate, dbo.TellerTransactionDetails.CashOpeningBal, dbo.TellerTransactionDetails.CashAmount, 
                      dbo.TellerTransactionDetails.CashOpeningBal + dbo.TellerTransactionDetails.CashAmount AS CashBal, dbo.TellerTransactionDetails.ChequeOpeningBal, 
                      dbo.TellerTransactionDetails.ChequeAmount, dbo.TellerTransactionDetails.ChequeOpeningBal + dbo.TellerTransactionDetails.ChequeAmount AS ChequeBal, 
                      dbo.Users.FullNames, dbo.TellerTransactionDetails.UserId, dbo.TellerTransactionDetails.TransactionDetailsId, 
                      dbo.fx_Return_Description(dbo.TellerTransactionDetails.TransactionDetailsId) AS Description, dbo.TellerTransactionDetails.Description AS TellerDescription, 
                      CASE dbo.TellerTransactionDetails.Description WHEN 'Cash Sale' THEN 1 WHEN 'Cheque Sale' THEN 2 WHEN 'Cash Collection' THEN 3 ELSE 1 END AS StatementOrder,
                       dbo.POSes.POSName
FROM         dbo.TellerTransactionDetails INNER JOIN
                      dbo.Users ON dbo.TellerTransactionDetails.UserId = dbo.Users.UserId INNER JOIN
                      dbo.POSes ON dbo.Users.POSId = dbo.POSes.POSID
WHERE     (dbo.TellerTransactionDetails.Description NOT IN ('Cash Collection', 'Cash Collection Reversal'))
UNION ALL
SELECT     TOP (100) PERCENT TellerTransactionDetails_2.TransactionDate, TellerTransactionDetails_2.CashOpeningBal, TellerTransactionDetails_2.CashAmount, 
                      TellerTransactionDetails_2.CashOpeningBal + TellerTransactionDetails_2.CashAmount AS CashBal, TellerTransactionDetails_2.ChequeOpeningBal, 
                      TellerTransactionDetails_2.ChequeAmount, TellerTransactionDetails_2.ChequeOpeningBal + TellerTransactionDetails_2.ChequeAmount AS ChequeBal, 
                      Users_2.FullNames, TellerTransactionDetails_2.UserId, TellerTransactionDetails_2.TransactionDetailsId, TellerTransactionDetails_2.Description, 
                      TellerTransactionDetails_2.Description AS TellerDescription, 1 AS StatementOrder, POSes_2.POSName
FROM         dbo.TellerTransactionDetails AS TellerTransactionDetails_2 INNER JOIN
                      dbo.Users AS Users_2 ON TellerTransactionDetails_2.UserId = Users_2.UserId INNER JOIN
                      dbo.POSes AS POSes_2 ON Users_2.POSId = POSes_2.POSID
WHERE     (TellerTransactionDetails_2.Description IN ('Cash Collection', 'Cash Collection Reversal'))
UNION ALL
SELECT     TOP (100) PERCENT TellerTransactionDetails_1.TransactionDate, TellerTransactionDetails_1.CashOpeningBal, TellerTransactionDetails_1.CashAmount, 
                      TellerTransactionDetails_1.CashOpeningBal + TellerTransactionDetails_1.CashAmount AS CashBal, TellerTransactionDetails_1.ChequeOpeningBal, 
                      TellerTransactionDetails_1.ChequeAmount, TellerTransactionDetails_1.ChequeOpeningBal + TellerTransactionDetails_1.ChequeAmount AS ChequeBal, 
                      Users_1.FullNames, TellerTransactionDetails_1.UserId, TellerTransactionDetails_1.TransactionDetailsId, TellerTransactionDetails_1.Description, 
                      TellerTransactionDetails_1.Description AS TellerDescription, 2 AS StatementOrder, POSes_1.POSName
FROM         dbo.TellerTransactionDetails AS TellerTransactionDetails_1 INNER JOIN
                      dbo.Users AS Users_1 ON TellerTransactionDetails_1.UserId = Users_1.UserId INNER JOIN
                      dbo.POSes AS POSes_1 ON Users_1.POSId = POSes_1.POSID
WHERE     (TellerTransactionDetails_1.Description IN ('Cash Collection', 'Cash Collection Reversal'))
go

