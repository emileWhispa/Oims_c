CREATE VIEW [dbo].[Vw_StockAdjustment]
AS
SELECT     dbo.StockAdjustment.StockAdjustmentID, dbo.StockAdjustment.AdjustmentDate, dbo.POSes.POSName, dbo.Products.ProductName, 
                      CASE dbo.StockAdjustment.AdjustmentType WHEN 1 THEN 'Increase' ELSE 'Decrease' END AS AdjustmentType, dbo.StockAdjustment.QuantityAdjusted, 
                      CASE dbo.StockAdjustment.Authorized WHEN 1 THEN 'Yes' ELSE 'No' END AS Authorized, dbo.POSes.POSID, dbo.StockAdjustment.Comments, 
                      dbo.Products.ProductId
FROM         dbo.StockAdjustment INNER JOIN
                      dbo.POSes ON dbo.StockAdjustment.PosID = dbo.POSes.POSID INNER JOIN
                      dbo.Products ON dbo.StockAdjustment.ProductId = dbo.Products.ProductId
go

