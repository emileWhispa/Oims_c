create FUNCTION [dbo].[fx_Return_Description]
(
	@TransactionDetailsID int
)
RETURNS varchar(50)
AS
BEGIN
	declare @descr varchar(50), @SalesPaymentId int
	if exists(select * from TellerTransactionDetails where TransactionDetailsID=@TransactionDetailsID and Description in ('Cash Sale','Cheque Sale'))
	begin
	select @SalesPaymentId=SalesPaymentId from TellerTransactionDetails where TransactionDetailsID=@TransactionDetailsID
	SELECT @descr=isnull(invoicenumber, salesref) from SalesPayments a, Sales b
	where a.SalesId=b.SalesId and a.SalesPaymentId=@SalesPaymentId
	end
	else
	BEGIN
	SELECT @descr=Description from TellerTransactionDetails where TransactionDetailsID=@TransactionDetailsID AND Description NOT in ('Cash Sale','Cheque Sale')
	END	
-- Return the result of the function
	RETURN @descr

END
go

