CREATE procedure sp_cancel_invoice
@SalesId int, @description varchar(50),@userid int
AS 
BEGIN
SET NOCOUNT ON;
Declare @POSId int,@ProductId int,@qty int,@availableQty int,@res int
select @POSId=POSId from Sales where SalesId=@SalesId
--Reversing the deliveries related to this invoice
DECLARE Stock_CURSOR CURSOR FOR SELECT b.ProductId,a.QuantityPicked FROM ItemDelivery a, SalesDetails b
where a.SalesDetailsId=b.SalesDetailsId and a.Status=0 and b.SalesId=@SalesId;
OPEN Stock_CURSOR;
FETCH NEXT FROM Stock_CURSOR INTO @ProductId, @qty;
	WHILE @@FETCH_STATUS =0  
	BEGIN
		select @availableQty=Quantity from stockitems where Posid=@PosId and ProductId=@ProductId
		--insert into stock card table
		insert into StockCard (ProductId,POsId,OpeningQuantity,QuantityIn, QuantityOut,Description,UserId, TranDate) values
		(@ProductId,@Posid,isnull(@availableQty,0),@qty,0,@description,@userid,getdate())
		Update StockItems set quantity=Quantity+@Qty where Posid=@Posid and ProductId=@ProductId
		FETCH NEXT FROM Stock_CURSOR INTO @ProductId, @qty;
	END
CLOSE Stock_CURSOR;
DEALLOCATE Stock_CURSOR;

--Reversing Cash Collected from this Invoice
declare @SalesPaymentId int, @Amount float, @PaymentModeId int, @openBalCash float, @openBalCheque float
DECLARE Payment_CURSOR CURSOR FOR SELECT SalesPaymentId,Amount,PaymentModeId  FROM SalesPayments
where SalesId=@SalesId;
OPEN Payment_CURSOR;
FETCH NEXT FROM Payment_CURSOR INTO @SalesPaymentId, @Amount, @PaymentModeId;
	WHILE @@FETCH_STATUS =0  
	BEGIN
			if @PaymentModeId=1--Cash Sale
			begin
				select @openBalCash=TotalCash, @openBalCheque=TotalCheque from TellerBalances where UserId=@UserId
				--Record Reversal Details
				insert into dbo.TellerTransactionDetails(SalesPaymentId,UserId,CashOpeningBal,CashAmount,ChequeOpeningBal,ChequeAmount,Description,TransactionDate)
					values(@SalesPaymentId,@userID,isnull(@openBalCash,0),@Amount*-1,isnull(@openBalCheque,0),0,@Description,getdate())

				update TellerBalances set TotalCash=TotalCash-@Amount where UserId=@userId
			end
			else if @PaymentModeId=2--Cheque Sale
			begin
				select @openBalCash=TotalCash, @openBalCheque=TotalCheque from TellerBalances where UserId=@UserId
				--Record Reversal Details
				insert into dbo.TellerTransactionDetails(SalesPaymentId,UserId,CashOpeningBal,CashAmount,ChequeOpeningBal,ChequeAmount,Description,TransactionDate)
					values(@SalesPaymentId,@userID,isnull(@openBalCash,0),0,isnull(@openBalCheque,0),@Amount*-1,@Description,getdate())
				
				update TellerBalances set TotalCheque=TotalCheque-@Amount where UserId=@userId
			end
			else if @PaymentModeId=4--Credit Sale
			begin
				select @openBalCash=TotalCash, @openBalCheque=TotalCheque from TellerBalances where UserId=@UserId
				--Record Reversal Details
				insert into dbo.TellerTransactionDetails(SalesPaymentId,UserId,CashOpeningBal,CashAmount,ChequeOpeningBal,ChequeAmount,Description,TransactionDate)
					values(@SalesPaymentId,@userID,isnull(@openBalCash,0),0,isnull(@openBalCheque,0),@Amount*-1,@Description,getdate())
				
				update TellerBalances set TotalCheque=TotalCheque-@Amount where UserId=@userId
			end
	FETCH NEXT FROM Payment_CURSOR INTO @SalesPaymentId, @Amount, @PaymentModeId;
	END
CLOSE Payment_CURSOR;
DEALLOCATE Payment_CURSOR;
END
go

